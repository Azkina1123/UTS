Langkah me-reset data yang tersimpan pada database :
1). Pastikan file create_database, create_data_default, dan KELOMPOK_FORTRAN berada dalam folder yang sama
2). Hapus file database yang ada
3). Run file create_database
4). Run file create_data_default

Jika tidak ingin menggunakan data default, maka tidak perlu menjalankan langkah 3 dan program tidak akan menyimpan data apapun.